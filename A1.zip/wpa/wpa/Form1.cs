using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Reflection.Metadata;
using System.Text;
using static System.Net.Mime.MediaTypeNames;
using static System.Net.WebRequestMethods;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Text.Json;
using System.Runtime.Serialization.Formatters.Binary;







namespace wpa
{
    public partial class Form1 : Form
    {
        byte command;
        public Form1()
        {
            InitializeComponent();
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            try
            {
                command = 0;
                byte[] buffer = new byte[1024 * 1024];
                TcpClient client = new TcpClient();
                await client.ConnectAsync("localhost", 8888);
                NetworkStream stream = client.GetStream();
                textBox2.Text = "Connected to server.";
                stream.WriteByte(command);

                stream.Read(buffer, 0, buffer.Length);
                string receivedString = Encoding.UTF8.GetString(buffer); // ���ֽ�����ת��Ϊ�ַ���
                string[] files = receivedString.Split(','); // ʹ��","�ָ��ַ�����ȡ�ļ����б�
                foreach (string file in files)
                {
                    checkedListBox1.Items.Add(file); // ����ļ���
                }
            }
            catch (Exception ex)
            {
                textBox2.Text = "Error connecting to server: " + ex.Message;
            }
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private async void button3_Click(object sender, EventArgs e)
        {
            command = 1;

            List<string> selectedFiles = new List<string>();

            for (int i = 0; i < checkedListBox1.Items.Count; i++)
            {
                if (checkedListBox1.GetItemChecked(i))
                {
                    selectedFiles.Add(checkedListBox1.Items[i].ToString()); // ����ѡ������ı����ļ��������ӵ��б���
                }
            }


            byte[] data = Encoding.UTF8.GetBytes(string.Join(",", selectedFiles));
            byte[] contend = new byte[1 + data.Length];
            contend[0] = command;
            Array.Copy(data, 0, contend, 1, data.Length);

            TcpClient client = new TcpClient("localhost", 8888);
            NetworkStream stream = client.GetStream();
            await stream.WriteAsync(contend, 0, contend.Length);


            byte[] buffer = new byte[1024 * 1024];
            for (int i = 0; i < selectedFiles.Count; i++)
            {
                string filename = selectedFiles[i].TrimEnd('\0');
                await stream.ReadAsync(buffer, 0, buffer.Length);


                string download_filepath = Path.Combine(@"C:\711\Client_files\", filename);
                System.IO.File.WriteAllBytes(download_filepath, buffer);

                /*string txt = Encoding.UTF8.GetString(buffer);
                textBox1.AppendText(selectedFiles[i]);
                textBox1.AppendText("'s content: ");
                textBox1.AppendText(txt);
                textBox1.AppendText("\r\n");*/
            }


            foreach (string file in selectedFiles)
            {
                checkedListBox2.Items.Add(file); // ����ļ���
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            List<string> selectedFiles = new List<string>();

            for (int i = 0; i < checkedListBox2.Items.Count; i++)
            {
                if (checkedListBox2.GetItemChecked(i))
                {
                    selectedFiles.Add(checkedListBox2.Items[i].ToString()); // ����ѡ������ı����ļ��������ӵ��б���
                }
            }

            for (int i = 0; i < selectedFiles.Count; i++)
            {
                string filename = selectedFiles[i].TrimEnd('\0');
                string txt = System.IO.File.ReadAllText(@"C:\711\Client_files\" + filename);
                textBox1.AppendText(selectedFiles[i]);
                textBox1.AppendText("'s content: ");
                textBox1.AppendText(txt);
                textBox1.AppendText("\r\n");
            }

        }

        private async void button4_Click(object sender, EventArgs e)
        {
            TcpListener listener = new TcpListener(IPAddress.Any, 60000);
            listener.Start();
            textBox2.AppendText("listening to server");
            while (true)
            {
                TcpClient client = await listener.AcceptTcpClientAsync();
                HandleClient(client);
            }
        }

        private async void HandleClient(TcpClient client)
        {
            NetworkStream stream = client.GetStream();
            command = (byte)stream.ReadByte();
            if (command == 0)
            {
                textBox2.Text = "success to listen server";
            }

            if (command == 1)
            {
                byte[] buffer = new byte[1024 * 1024];
                byte[] content = new byte[1024 * 1024];
                await stream.ReadAsync(buffer, 0, buffer.Length);
                string dataString = Encoding.UTF8.GetString(buffer).TrimEnd('\0');

                // ���ַ������Ϊ�ַ�������
                string[] selectedFiles = dataString.Split(',');
                textBox1.AppendText("server request: " + dataString);
                textBox1.AppendText(" at ");
                textBox1.AppendText(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                textBox1.AppendText("\r\n");

                byte[] receivedBytes = new byte[1024 * 1024];
                stream.Read(receivedBytes, 0, receivedBytes.Length);


                int lastIndex = Array.FindLastIndex<byte>(receivedBytes, b => b != 0);

                // ����ҵ��˷���Ԫ�أ�������Ĵ�С���µ���Ϊ������+1
                if (lastIndex >= 0)
                {
                    Array.Resize(ref receivedBytes, lastIndex + 1);
                }


                Dictionary<int, byte[]> dicSocket = JsonSerializer.Deserialize<Dictionary<int, byte[]>>(receivedBytes);


                List<int> keys = new List<int>(dicSocket.Keys);

                // ��ȡ�ֵ�������ֵ�ļ���
                List<byte[]> values = new List<byte[]>(dicSocket.Values);

                for (int i = 0; i < dicSocket.Count; i++)
                {
                    string filepath = @"C:\711\Client_files\" + selectedFiles[i].TrimEnd('\0');
                    byte[] value = values[i];
                    string con = Encoding.UTF8.GetString(value);
                    System.IO.File.WriteAllText(filepath, con);

                }

                string folderPath = @"C:\711\Client_files\";
                string[] fileNames = Directory.GetFiles(folderPath, "*.txt").Select(Path.GetFileName).ToArray();
                List<string> selectedFiles1 = new List<string>(fileNames);

                foreach (string a in selectedFiles1)
                {
                    checkedListBox2.Items.Add(a);
                }


            }
        }
    }
}