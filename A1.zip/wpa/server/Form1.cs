using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text.Json;


namespace server
{
    public partial class Form1 : Form   //server
    {
        private TcpListener listener;
        byte command = 0;
        public Form1()
        {
            InitializeComponent();
            listener = new TcpListener(IPAddress.Any, 8889);
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            listener.Start();
            textBox1.Text = "Server started. Listening for connections...";
            while (true)
            {
                TcpClient client = await listener.AcceptTcpClientAsync();
                HandleClient(client);
            }
        }

        private async void HandleClient(TcpClient client)
        {
            NetworkStream stream = client.GetStream();
            command = (byte)stream.ReadByte();
            if (command == 0)
            {
                textBox1.Text = "request received";
                string folderPath = @"C:\711\Server_files\"; // ָ���ļ���·��

                string[] files = Directory.GetFiles(folderPath).Select(Path.GetFileName).ToArray();
                byte[] filesBytes = Encoding.UTF8.GetBytes(string.Join(",", files)); // ���ļ����б�ת��Ϊbyte����

                stream.Write(filesBytes, 0, filesBytes.Length);

                foreach (string file in files)
                {
                    checkedListBox1.Items.Add(file); // ����ļ���
                }
            }

            if (command == 1)
            {
                byte[] buffer = new byte[1024 * 1024];
                await stream.ReadAsync(buffer, 0, buffer.Length);
                string dataString = Encoding.UTF8.GetString(buffer).TrimEnd('\0');

                string[] selectedFiles = dataString.Split(',');

                textBox2.AppendText("CACHE request: " + dataString);
                textBox2.AppendText(" at ");
                textBox2.AppendText(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                textBox2.AppendText("\r\n");

                for (int i = 0; i < selectedFiles.Length; i++)
                {
                    string path = Path.Combine(@"C:\711\Server_files\", selectedFiles[i]);
                    string fileContent = File.ReadAllText(path);
                    byte[] response = Encoding.ASCII.GetBytes(fileContent);
                    stream.Write(response, 0, response.Length);
                }
            }
        }

        private async void button2_Click(object sender, EventArgs e)
        {
            TcpClient serverClient = new TcpClient();
            await serverClient.ConnectAsync("10.3.7.29", 60000);
            NetworkStream serverStream = serverClient.GetStream();
            textBox3.Text = "Connected to client.";
            command = 0;
            serverStream.WriteByte(command);



            string folderPath = @"C:\711\Server_files\"; // ָ���ļ���·��

            string[] files = Directory.GetFiles(folderPath).Select(Path.GetFileName).ToArray();
            foreach (string file in files)
            {
                checkedListBox1.Items.Add(file); // ����ļ���
            }

        }

        private async void button3_Click(object sender, EventArgs e)
        {

            TcpClient client = new TcpClient("localhost", 60000);
            NetworkStream stream = client.GetStream();
            byte[] buffer = new byte[1024 * 1024];
            byte[] filenamebuffer = new byte[1024 * 1024];
            command = 1;




            List<string> selectedFiles = new List<string>();

            for (int i = 0; i < checkedListBox1.Items.Count; i++)
            {
                if (checkedListBox1.GetItemChecked(i))
                {
                    selectedFiles.Add(checkedListBox1.Items[i].ToString()); // ����ѡ������ı����ļ��������ӵ��б���
                }
            }

            byte[] data = Encoding.UTF8.GetBytes(string.Join(",", selectedFiles));
            byte[] contend = new byte[1 + data.Length];
            contend[0] = command;
            Array.Copy(data, 0, contend, 1, data.Length);
            await stream.WriteAsync(contend, 0, contend.Length);


            Dictionary<int, byte[]> dicSocket = new Dictionary<int, byte[]>();


            for (int i = 0; i < selectedFiles.Count; i++)
            {

                string filename = selectedFiles[i].TrimEnd('\0');
                string txt = System.IO.File.ReadAllText(@"C:\711\Server_files\" + filename);
                textBox2.AppendText("sending: " + filename);
                textBox2.AppendText("\r\ncontent: " + txt);
                textBox2.AppendText("\r\n");
                byte[] response = Encoding.ASCII.GetBytes(txt);
                dicSocket.Add(i, response);
            }

            foreach (KeyValuePair<int, byte[]> kvp in dicSocket)
            {
                textBox2.AppendText($"Key: {kvp.Key}");

                // ���byte[]�����ʮ�����Ʊ�ʾ
                textBox2.AppendText("Value: " + BitConverter.ToString(kvp.Value));
                textBox2.AppendText("\r\n");
            }

            byte[] bytesToSend = JsonSerializer.SerializeToUtf8Bytes(dicSocket);
            stream.Write(bytesToSend, 0, bytesToSend.Length);

        }
    }
}