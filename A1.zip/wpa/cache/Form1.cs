using Microsoft.VisualBasic.Logging;
using System.Net;
using System.Net.Sockets;
using System.Text;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text.Json;

namespace cache
{
    public partial class Form1 : Form
    {
        TcpListener listener;
        NetworkStream stream;
        byte command;

        byte[] content = new byte[1024 * 1024];

        public Form1()
        {
            InitializeComponent();
            listener = new TcpListener(IPAddress.Any, 8888);
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            listener.Start();
            while (true)
            {
                TcpClient client = await listener.AcceptTcpClientAsync();
                HandleClient(client);
            }
        }

        private async void HandleClient(TcpClient client)
        {
            stream = client.GetStream();
            byte command = (byte)stream.ReadByte();
            if (command == 0)
            {
                TcpClient serverClient = new TcpClient();
                await serverClient.ConnectAsync("localhost", 8889);
                NetworkStream serverStream = serverClient.GetStream();
                serverStream.WriteByte(command);
                byte[] buffer = new byte[1024 * 1024];
                serverStream.Read(buffer, 0, buffer.Length);
                stream.Write(buffer, 0, buffer.Length);
            }


            if (command == 1)
            {
                byte[] buffer = new byte[1024 * 1024];
                await stream.ReadAsync(buffer, 0, buffer.Length);
                string dataString = Encoding.UTF8.GetString(buffer).TrimEnd('\0');

                // ���ַ������Ϊ�ַ�������
                string[] selectedFiles = dataString.Split(',');

                textBox1.AppendText("user request: " + dataString);
                textBox1.AppendText(" at ");
                textBox1.AppendText(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                textBox1.AppendText("\r\n");

                string logpath = Path.Combine(@"C:\711\Cache_files\", "log.txt");

                for (int i = 0; i < selectedFiles.Length; i++)
                {
                    string filepath = Path.Combine(@"C:\711\Cache_files\", selectedFiles[i]);
                    if (File.Exists(filepath))
                    {
                        string fileContent = File.ReadAllText(filepath);
                        byte[] response = Encoding.ASCII.GetBytes(fileContent);
                        stream.Write(response, 0, response.Length);
                        string logMessage = $"user request: file {selectedFiles[i]} at {DateTime.Now}\r\nresponse: cached file {selectedFiles[i]}\r\n";
                        File.AppendAllText(logpath, logMessage);
                    }
                    else
                    {
                        string result = selectedFiles[i] + "down load from server";
                        TcpClient serverClient = new TcpClient();
                        await serverClient.ConnectAsync("localhost", 8889);
                        NetworkStream serverStream = serverClient.GetStream();
                        serverStream.WriteByte(command);

                        byte[] ask = Encoding.ASCII.GetBytes(selectedFiles[i]);
                        await serverStream.WriteAsync(ask, 0, ask.Length);


                        byte[] requestfile = new byte[1024 * 1024];
                        await serverStream.ReadAsync(requestfile, 0, content.Length);
                        await stream.WriteAsync(requestfile, 0, content.Length);

                        string logMessage = $"user request: file {selectedFiles[i]} at {DateTime.Now}\r\nresponse: downloaded from the server {selectedFiles[i]}\r\n";
                        File.AppendAllText(logpath, logMessage);

                        string download_filepath = Path.Combine(@"C:\711\Cache_files\", selectedFiles[i]);
                        File.WriteAllBytes(download_filepath, requestfile);



                    }
                }


            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string folderPath = @"C:\711\Cache_files\";

            try
            {
                DirectoryInfo directory = new DirectoryInfo(folderPath);

                foreach (FileInfo file in directory.GetFiles())
                {
                    file.Delete();
                }

                MessageBox.Show("��log.txt�ļ���������ļ��ѳɹ�ɾ����");
            }
            catch (Exception ex)
            {
                MessageBox.Show("ɾ���ļ�ʱ���ִ��� " + ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                string log = File.ReadAllText(@"C:\711\Cache_files\log.txt");
                textBox2.Text = log;
            }
            catch { textBox2.Text = "�Ѳ�����log.txt"; }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string folderPath = @"C:\711\Cache_files\";
            textBox3.Text = "";
            try
            {
                DirectoryInfo directory = new DirectoryInfo(folderPath);
                if (directory.GetFiles().Length > 0)
                {
                    foreach (FileInfo file in directory.GetFiles())
                    {
                        if (file.Name != "log.txt")
                        {
                            string content = File.ReadAllText(file.FullName);
                            textBox3.AppendText(file.Name + " : ");
                            textBox3.AppendText(content);
                        }
                        textBox3.AppendText("\r\n");
                    }
                }
                else { textBox3.Text = "No cached files!"; }
            }
            catch { }
        }
    }
}